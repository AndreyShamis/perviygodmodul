//-------------- include section -----------------------------------------------
#include <iostream>

//-------------- using section -------------------------------------------------
using std::cout;
using std::cin;
using std::endl;

//-------------- const and enum section ----------------------------------------
const int ???;

//-------------- main ----------------------------------------------------------
int main ()
{
int arr1[5];	//not format
	arr2[5]={1,17,3,9,5}; //format according to the line (left to right).
	arr3[5]={17,5};		  //format the 2 first nums, and all others are 0.
	arr4[5]={0};		  //evrything is format to be 0.
	arr5[ ]={1,2,3,4}; 	  //the compiler will no to make 4 cells.
	arr6[5][7];	//not format
	arr7[3][5]={{2,3,7,3,2},{1,1,1,1,1},{3,4,5,0,1}};  //formating (l.to r.)
